package com.prajay.nova

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(8, 11, 24)
    private val panel = Color.rgb(21, 27, 51)
    private val purple = Color.rgb(151, 105, 255)
    private val blue = Color.rgb(48, 155, 255)
    private val orange = Color.rgb(255, 145, 72)
    private lateinit var clockView: TextView
    private lateinit var appGrid: LinearLayout
    private var selectedFilter = "All"
    private var pendingFocusTag: String? = null

    private data class TvApp(
        val label: String,
        val packageName: String,
        val icon: android.graphics.drawable.Drawable,
        val isTvApp: Boolean
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        buildInterface()
        updateClock()
    }

    override fun onResume() {
        super.onResume()
        if (::appGrid.isInitialized) refreshApps()
    }

    private fun buildInterface() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(25), dp(42), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(20, 20, 55), navy, Color.rgb(35, 17, 52))
            )
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val logo = TextView(this).apply {
            text = "NOVA"
            textSize = 29f
            letterSpacing = 0.20f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        }
        val tagline = TextView(this).apply {
            text = "  YOUR SCREEN. YOUR UNIVERSE."
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(Color.rgb(151, 161, 196))
        }
        val logoGroup = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(logo)
            addView(tagline)
        }
        clockView = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(207, 211, 235))
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            text = clockText()
        }
        header.addView(logoGroup, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(clockView, LinearLayout.LayoutParams(-2, dp(48)))
        page.addView(header)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(15), dp(22), dp(15))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(83, 54, 153), Color.rgb(28, 87, 154), Color.rgb(112, 55, 120))
            ).apply { cornerRadius = dp(22).toFloat() }
        }
        val hello = TextView(this).apply {
            text = "WELCOME TO NOVA"
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(226, 218, 255))
        }
        val headline = TextView(this).apply {
            text = "Find your next favourite."
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, dp(5), 0, dp(3))
        }
        val subline = TextView(this).apply {
            text = "Your apps, together in one place."
            textSize = 13f
            setTextColor(Color.rgb(226, 229, 255))
        }
        hero.addView(hello)
        hero.addView(headline)
        hero.addView(subline)
        val heroParams = LinearLayout.LayoutParams(-1, dp(112))
        heroParams.setMargins(0, dp(15), 0, dp(17))
        page.addView(hero, heroParams)

        val sectionHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val sectionTitle = TextView(this).apply {
            text = "YOUR APPS"
            textSize = 12f
            letterSpacing = 0.15f
            setTextColor(Color.rgb(188, 195, 224))
            typeface = Typeface.DEFAULT_BOLD
        }
        val hint = TextView(this).apply {
            text = "  •  Select with your remote"
            textSize = 11f
            setTextColor(Color.rgb(116, 129, 169))
        }
        sectionHeader.addView(sectionTitle)
        sectionHeader.addView(hint)
        page.addView(sectionHeader)

        val filters = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipToPadding = false
        }
        val filterRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        listOf("All", "TV Apps", "More Apps").forEach { name ->
            val chip = TextView(this).apply {
                text = name
                tag = name
                textSize = 12f
                setTextColor(if (name == selectedFilter) Color.WHITE else Color.rgb(164, 174, 207))
                gravity = Gravity.CENTER
                setPadding(dp(15), dp(8), dp(15), dp(8))
                background = chipBackground(name == selectedFilter)
                isFocusable = true
                setOnClickListener {
                    selectedFilter = name
                    pendingFocusTag = name
                    buildInterface()
                }
            }
            val lp = LinearLayout.LayoutParams(-2, dp(34))
            lp.setMargins(0, dp(9), dp(8), dp(8))
            filterRow.addView(chip, lp)
        }
        filters.addView(filterRow)
        page.addView(filters)

        val scroller = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        appGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(10))
        }
        scroller.addView(appGrid)
        page.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "NOVA  •  PREVIEW 0.2     |     Built for the big screen"
            textSize = 10f
            letterSpacing = 0.06f
            setTextColor(Color.rgb(102, 116, 155))
            setPadding(0, dp(8), 0, 0)
        }
        page.addView(footer)
        setContentView(page)
        refreshApps()
        page.post {
            val target = pendingFocusTag?.let { page.findViewWithTag<View>(it) }
            pendingFocusTag = null
            if (target != null) target.requestFocus() else focusFirstAppOrChip(page)
        }
    }

    private fun refreshApps() {
        if (!::appGrid.isInitialized) return
        appGrid.removeAllViews()
        val apps = discoverApps().filter {
            when (selectedFilter) {
                "TV Apps" -> it.isTvApp
                "More Apps" -> !it.isTvApp
                else -> true
            }
        }
        if (apps.isEmpty()) {
            appGrid.addView(TextView(this).apply {
                text = "No apps found in this category."
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
            return
        }

        val columns = 4
        apps.chunked(columns).forEach { group ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            group.forEachIndexed { index, app ->
                val tile = makeAppTile(app, index)
                val params = LinearLayout.LayoutParams(0, dp(92), 1f)
                params.setMargins(dp(5), dp(6), dp(5), dp(6))
                row.addView(tile, params)
            }
            repeat(columns - group.size) {
                row.addView(View(this), LinearLayout.LayoutParams(0, dp(92), 1f))
            }
            appGrid.addView(row)
        }
    }

    private fun discoverApps(): List<TvApp> {
        val pm = packageManager
        val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val appIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = linkedMapOf<String, TvApp>()

        fun addResults(results: List<ResolveInfo>, tv: Boolean) {
            results.forEach { info ->
                val pkg = info.activityInfo?.packageName ?: return@forEach
                if (pkg == packageName) return@forEach
                val label = info.loadLabel(pm)?.toString() ?: pkg
                val icon = try { info.loadIcon(pm) } catch (_: Exception) { getDrawable(android.R.drawable.sym_def_app_icon)!! }
                val old = found[pkg]
                found[pkg] = TvApp(label, pkg, icon, tv || (old?.isTvApp == true))
            }
        }

        addResults(pm.queryIntentActivities(tvIntent, 0), true)
        addResults(pm.queryIntentActivities(appIntent, 0), false)
        return found.values.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun makeAppTile(app: TvApp, position: Int): View {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = tileBackground(false, position)
            isFocusable = true
            isFocusableInTouchMode = true
            contentDescription = "Open ${app.label}"
            setOnFocusChangeListener { view, focused ->
                view.background = tileBackground(focused, position)
                view.animate().scaleX(if (focused) 1.055f else 1f)
                    .scaleY(if (focused) 1.055f else 1f).setDuration(120).start()
            }
            setOnClickListener { launchApp(app.packageName) }
            setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_UP &&
                    (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER)) {
                    launchApp(app.packageName)
                    true
                } else false
            }
        }
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        tile.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
        val label = TextView(this).apply {
            text = app.label
            textSize = 11f
            maxLines = 1
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
        }
        tile.addView(label, LinearLayout.LayoutParams(-1, -2))
        return tile
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(packageName)
            ?: packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            try { startActivity(intent) } catch (_: Exception) { }
        }
    }

    private fun tileBackground(focused: Boolean, index: Int) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (focused) intArrayOf(purple, blue) else {
            val base = when (index % 3) {
                0 -> Color.rgb(35, 39, 75)
                1 -> Color.rgb(29, 48, 77)
                else -> Color.rgb(55, 37, 72)
            }
            intArrayOf(base, Color.rgb(24, 29, 53))
        }
    ).apply {
        cornerRadius = dp(17).toFloat()
        setStroke(dp(1), if (focused) Color.rgb(220, 204, 255) else Color.argb(35, 210, 220, 255))
    }

    private fun chipBackground(active: Boolean) = GradientDrawable().apply {
        setColor(if (active) Color.rgb(92, 63, 157) else panel)
        cornerRadius = dp(17).toFloat()
        setStroke(dp(1), if (active) purple else Color.argb(35, 210, 220, 255))
    }

    private fun focusFirstAppOrChip(view: View) {
        val focusables = view.focusables(View.FOCUS_FORWARD)
        focusables.firstOrNull { it.isFocusable }?.requestFocus()
    }

    private fun clockText(): String =
        SimpleDateFormat("EEE, d MMM   •   h:mm a", Locale.getDefault()).format(Date())

    private fun updateClock() {
        clockView.text = clockText()
        clockView.postDelayed({ if (!isFinishing) updateClock() }, 60_000)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
