Project: NOVA Launcher v0.2

Goal: a lightweight, vibrant Android TV HOME launcher for an Airtel Xstream Smart Box HSW4026ATL running Android TV OS 11. Visual direction: futuristic, vibrant purple/blue/orange, dark navy background, clean TV-first layout.

Read the entire project before changing code. It uses Kotlin, native Android Views, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, JDK 17, compileSdk 35, targetSdk 30, minSdk 23.

Current features: HOME/DEFAULT intent, Leanback launcher entry, package visibility queries, app discovery, app icons, app filters, D-pad focus tile animation, date/time.

Tasks:
1. Review compile correctness and Android 11 compatibility.
2. Fix any compilation or runtime issues with minimal dependencies.
3. Improve D-pad focus navigation and focus restoration after returning from an app.
4. Add a safe route to open the stock Airtel launcher if feasible without relying on hidden/private APIs.
5. Keep performance appropriate for a low-memory TV box.
6. Do not root, flash, replace firmware, disable Airtel packages, or automatically set NOVA as default HOME.
7. Never claim it was tested on the physical Airtel box unless that testing actually happened.
