# NOVA Launcher v0.2

A lightweight, vibrant Android TV launcher prototype written in Kotlin using native Android Views.

## What's included
- HOME/DEFAULT activity registration (can be selected as a home app if the device permits it).
- Android TV Leanback launcher entry.
- Installed app discovery through Leanback and standard launcher intents.
- App icons and labels.
- D-pad focus states with short scale animations.
- All / TV Apps / More Apps filters.
- Vibrant purple, blue and orange visual direction.
- Date and time.
- No network permission and no third-party runtime dependencies.

## Build requirements
- Android Studio or a compatible Android Gradle environment.
- JDK 17.
- Android SDK platform 35.
- Android Gradle Plugin 8.7.3.
- Kotlin Gradle plugin 2.0.21.

Open the project root folder in Android Studio, sync Gradle, then choose Build > Build APK(s).

## Important compatibility notes
- This is source code, not a prebuilt APK.
- It has not been compiled or tested on the Airtel Xstream HSW4026ATL device.
- The manifest targets SDK 30 and declares package visibility queries for standard and Leanback launcher activities. Android/OEM policy may still hide some apps.
- The box's firmware may prevent changing the default HOME app or launching some protected system apps.
- Keep the stock Airtel launcher available. Test NOVA as a normal app first, then test HOME selection only if the device offers it.
- Do not modify firmware, root the box, or disable Airtel system packages for this project.

## Current limitations / next improvements
- Add robust D-pad focus restoration after returning from an app.
- Improve focus movement across the grid and filters.
- Add user-configurable favourites and theme settings.
- Add a settings screen and a safe "Open stock launcher" action.
- Validate layout on the actual 720p/1080p output and device density.
